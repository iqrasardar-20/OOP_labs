import java.util.Scanner;

public class task8{

public static void main(String args[]){

Scanner src=new Scanner(System.in);

System.out.print("Enter a speed in miles per hour: ");

int speed=src.nextInt();

System.out.println("The converted value is: "+(speed*1.6));



}

}