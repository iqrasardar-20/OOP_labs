public class task1{
public static void main (String [] arguments){

System.out.println("////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\");
System.out.println("==\t\tStudent Points\t\t==");
System.out.println("////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\");
System.out.println("Lab\t\tBonus\t\tTotal");
System.out.println("-----\t\t-----\t\t-----");
System.out.println("43\t\t7\t\t50");
System.out.println("50\t\t8\t\t58");
System.out.println("39\t\t10\t\t49");


}
}