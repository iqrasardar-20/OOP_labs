class Main{
    public static void main(String args []){
    Dog sound = new Dog(" sonu ,", 3);
    sound.displayInfo();
    System.out.println();
    sound.makeSound();
        
    }
}