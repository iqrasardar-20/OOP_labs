class Main3{
    public static void main(String args []){
   Car C = new Car("fortuner", 23, 4);
   C.showDetails();
   System.out.println();
   Bike B = new Bike("biko", 43, "Covered");
B.showDetails();

        
    }
    
}