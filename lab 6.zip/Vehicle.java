class Vehicle{
    String brand;
    double speed;

Vehicle(String brand , double speed ){
    this.brand=brand;
    this.speed=speed;
}

    public void showDetails(){
        System.out.println("Brand  : "+brand);
        System.out.println("Speed   : "+speed);
    }
}