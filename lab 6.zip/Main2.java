class Main2{
    public static void main(String args []){

 GraduateStudent G= new GraduateStudent("Iqra Sardar",21,"168","AI");
 
    G.displayInfo();
        
    }
}