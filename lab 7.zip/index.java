import java.util.Scanner;
 class index{
 public static void main(String[] args) {
 	
		Scanner input = new Scanner(System.in);

		System.out.println("Enter any String ");
		String letter=input.nextLine();

		int index=letter.indexOf("a");
		System.out.println("Index of a is : "+index);
	}
 }