class hello{
		public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Enter any word : ");
		String word = input.nextLine();

		if(word.startsWith("Hello")){
			System.out.println("String starts with Hello ");
		}
		else
		{
			System.out.println("String does not starts with Hello");
		}
	}
}