public class Main1 {
public static void main(String [] arg){
Vehicle car = new Car();
Vehicle bike = new Bike ();
car.start();
car.stop();

bike.start();
bike.stop();
}

}