public class Bike implements
Vehicle{
public void start(){
System.out.println("Bike engine start. ");
}

public void stop(){
System.out.println("Bike engine stop");

}

}