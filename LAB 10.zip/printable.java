public class interface Printable{
  void print();
}