class Animal{
public void makeSound(){
System.out.println("Animal makes a sound");
}
}


